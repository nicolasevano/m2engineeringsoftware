var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":46,"id":2817,"methods":[{"el":35,"sc":5,"sl":33},{"el":39,"sc":5,"sl":37},{"el":45,"sc":5,"sl":41}],"name":"Same","sl":27}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_1045":{"methods":[{"sl":33},{"sl":41}],"name":"sameToStringWithObject","pass":true,"statements":[{"sl":34},{"sl":42},{"sl":43},{"sl":44}]},"test_1059":{"methods":[{"sl":33},{"sl":37}],"name":"testSame","pass":true,"statements":[{"sl":34},{"sl":38}]},"test_220":{"methods":[{"sl":33},{"sl":41}],"name":"sameToStringWithChar","pass":true,"statements":[{"sl":34},{"sl":42},{"sl":43},{"sl":44}]},"test_299":{"methods":[{"sl":33},{"sl":37}],"name":"testSame","pass":true,"statements":[{"sl":34},{"sl":38}]},"test_311":{"methods":[{"sl":33},{"sl":41}],"name":"sameToStringWithObject","pass":true,"statements":[{"sl":34},{"sl":42},{"sl":43},{"sl":44}]},"test_438":{"methods":[{"sl":33},{"sl":41}],"name":"sameToStringWithChar","pass":true,"statements":[{"sl":34},{"sl":42},{"sl":43},{"sl":44}]},"test_531":{"methods":[{"sl":33},{"sl":41}],"name":"sameToStringWithString","pass":true,"statements":[{"sl":34},{"sl":42},{"sl":43},{"sl":44}]},"test_85":{"methods":[{"sl":33},{"sl":41}],"name":"sameToStringWithString","pass":true,"statements":[{"sl":34},{"sl":42},{"sl":43},{"sl":44}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [299, 438, 531, 85, 220, 1059, 1045, 311], [299, 438, 531, 85, 220, 1059, 1045, 311], [], [], [299, 1059], [299, 1059], [], [], [438, 531, 85, 220, 1045, 311], [438, 531, 85, 220, 1045, 311], [438, 531, 85, 220, 1045, 311], [438, 531, 85, 220, 1045, 311], [], []]
